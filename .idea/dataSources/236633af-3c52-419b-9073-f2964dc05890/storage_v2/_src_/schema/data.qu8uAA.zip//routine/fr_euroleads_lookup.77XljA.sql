create
    definer = root@localhost procedure fr_euroleads_lookup(IN input_firstname varchar(128),
                                                           IN input_lastname varchar(128),
                                                           IN input_address1 varchar(255),
                                                           IN input_address2 varchar(255), IN input_zip varchar(64),
                                                           IN input_town varchar(255))
BEGIN

SELECT *, 1 as level FROM fr_euroleads WHERE 
firstname like concat('%', input_firstname, '%') and
lastname like concat('%', input_lastname, '%') and 
address1 like concat('%', input_address1, '%') and
address2 like concat('%', input_address2, '%') and
zip like concat('%', input_zip, '%') and
town like concat('%', input_town, '%') 

union

SELECT *, 2 as level FROM fr_euroleads WHERE 
lastname like concat('%', input_lastname, '%') and 
address1 like concat('%', input_address1, '%') and
(zip like concat('%', input_zip, '%') or town like concat('%', input_town, '%'))

union

SELECT *, 3 as level FROM fr_euroleads WHERE 
lastname like concat('%', input_lastname, '%') and 
(zip like concat('%', input_zip, '%') or town like concat('%', input_town, '%'))


order by level asc
limit 1;
END;

